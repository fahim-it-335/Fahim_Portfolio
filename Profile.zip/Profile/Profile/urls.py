
from django.contrib import admin
from django.urls import path, include
from django.urls import path 
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('fahim/',include('fahimapp.urls')),
    path('chat/', include('chat.urls')),
    path('', views.login, name='login'),
]
