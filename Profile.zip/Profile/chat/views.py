from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from .models import Message

@login_required
def send_message(request, receiver_id):
    if request.method == 'POST':
        content = request.POST.get('content')
        if content:
            receiver = User.objects.get(id=receiver_id)
            message = Message(sender=request.user, receiver=receiver, content=content)
            message.save()

            # Send a copy of the message to the admin user (replace 'admin_username' with the admin's username).
            admin_user = User.objects.get(username='admin_username')  # Replace with the admin's username.
            admin_message = Message(sender=request.user, receiver=admin_user, content=content)
            admin_message.save()

    return redirect('chat')
