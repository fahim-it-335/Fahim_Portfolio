from django.contrib import admin
from fahimapp.models import Contract

# Register your models here.
admin.site.register(Contract)
