from django.apps import AppConfig


class FahimappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fahimapp'
